package chat;

import chat_video.VoiceServer;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import chat_video.video_server;
import java.awt.Color;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.JFileChooser;
import javax.swing.text.BadLocationException;
import javax.swing.text.SimpleAttributeSet;
import javax.swing.text.StyleConstants;
import javax.swing.text.StyledDocument;

public class chat_server extends javax.swing.JFrame {

    
    static ServerSocket sss;
    static Socket ss;
    static DataInputStream din;
    static DataOutputStream dout;
    video_server videoServer = new video_server();
    
    public chat_server() {
        initComponents();
        msg_text.requestFocus();
        video_chat.setVisible(false);
    }

    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        msg_text = new javax.swing.JTextField();
        msg_send = new javax.swing.JButton();
        video_chat = new javax.swing.JButton();
        btnVoiceServer = new javax.swing.JButton();
        btnVoiceServerMax = new javax.swing.JButton();
        btnEndCall = new javax.swing.JButton();
        jScrollPane2 = new javax.swing.JScrollPane();
        txtPaneChat = new javax.swing.JTextPane();
        jButton1 = new javax.swing.JButton();
        jLabel1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("server");
        setBackground(new java.awt.Color(51, 153, 255));
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowOpened(java.awt.event.WindowEvent evt) {
                formWindowOpened(evt);
            }
        });
        getContentPane().setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        msg_text.setBackground(new java.awt.Color(204, 204, 255));
        msg_text.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msg_textActionPerformed(evt);
            }
        });
        getContentPane().add(msg_text, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 290, 352, 40));

        msg_send.setIcon(new javax.swing.ImageIcon(getClass().getResource("/sent_48px.png"))); // NOI18N
        msg_send.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                msg_sendActionPerformed(evt);
            }
        });
        getContentPane().add(msg_send, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 290, 48, 40));

        video_chat.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_video_call_40px.png"))); // NOI18N
        video_chat.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                video_chatActionPerformed(evt);
            }
        });
        getContentPane().add(video_chat, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 28, 55, 40));

        btnVoiceServer.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_call_40px.png"))); // NOI18N
        btnVoiceServer.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoiceServerActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoiceServer, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 129, 55, 38));

        btnVoiceServerMax.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_video_call_40px.png"))); // NOI18N
        btnVoiceServerMax.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnVoiceServerMaxActionPerformed(evt);
            }
        });
        getContentPane().add(btnVoiceServerMax, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 179, 55, 36));

        btnEndCall.setIcon(new javax.swing.ImageIcon(getClass().getResource("/icons8_call_30px_1.png"))); // NOI18N
        btnEndCall.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEndCallActionPerformed(evt);
            }
        });
        getContentPane().add(btnEndCall, new org.netbeans.lib.awtextra.AbsoluteConstraints(364, 80, 55, -1));

        txtPaneChat.setEditable(false);
        txtPaneChat.setBackground(new java.awt.Color(73, 73, 168));
        jScrollPane2.setViewportView(txtPaneChat);

        getContentPane().add(jScrollPane2, new org.netbeans.lib.awtextra.AbsoluteConstraints(6, 28, 352, 240));

        jButton1.setFont(new java.awt.Font("Yu Gothic UI Semibold", 0, 12)); // NOI18N
        jButton1.setText("File");
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                jButton1ActionPerformed(evt);
            }
        });
        getContentPane().add(jButton1, new org.netbeans.lib.awtextra.AbsoluteConstraints(360, 230, 60, 30));

        jLabel1.setIcon(new javax.swing.ImageIcon(getClass().getResource("/ggggg.jpg"))); // NOI18N
        getContentPane().add(jLabel1, new org.netbeans.lib.awtextra.AbsoluteConstraints(-3, -3, -1, 360));

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void msg_textActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msg_textActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_msg_textActionPerformed
// لتنسيق الرسائل داخل txtPaneChat
void appendMessage(String message, boolean isSender) {
    StyledDocument doc = txtPaneChat.getStyledDocument();

    // تحديد خصائص التنسيق
    SimpleAttributeSet attr = new SimpleAttributeSet();
    StyleConstants.setFontSize(attr, 14);
    StyleConstants.setForeground(attr, Color.WHITE);
    StyleConstants.setBackground(attr, isSender ? new Color(0, 132, 255) : new Color(96, 96, 96));
    StyleConstants.setAlignment(attr, isSender ? StyleConstants.ALIGN_RIGHT : StyleConstants.ALIGN_LEFT);
    StyleConstants.setLeftIndent(attr, 5);
    StyleConstants.setRightIndent(attr, 5);
    StyleConstants.setSpaceAbove(attr, 5);
    StyleConstants.setSpaceBelow(attr, 5);
    StyleConstants.setBold(attr, true);

    try {
        // إدراج الرسالة مع التنسيق
        doc.insertString(doc.getLength(), message + "\n", attr);
        doc.setParagraphAttributes(doc.getLength(), 1, attr, false);
    } catch (BadLocationException ex) {
        ex.printStackTrace();
    }
}
    
    private void msg_sendActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_msg_sendActionPerformed
           
        try {
            String msgout;
            msgout=msg_text.getText().trim();
            dout.writeUTF(msgout);
            appendMessage("Me: " + msgout, true);

        } catch (IOException ex) {
           
        }
                msg_text.setText("");

    }//GEN-LAST:event_msg_sendActionPerformed

    private void video_chatActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_video_chatActionPerformed
       
        try {
            video_server.startVideoServer();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(chat_server.class.getName()).log(Level.SEVERE, null, ex);
        }
    }//GEN-LAST:event_video_chatActionPerformed

    private void formWindowOpened(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowOpened
        // TODO add your handling code here:
        this.setBounds(800, 300, 450, 400);
    }//GEN-LAST:event_formWindowOpened

    private void btnVoiceServerActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoiceServerActionPerformed
      
        chat_video.VoiceServer voiceServer=new VoiceServer();
        voiceServer.setVisible(true);
        voiceServer.startVoiceCall();
        
    }//GEN-LAST:event_btnVoiceServerActionPerformed
        chat_video.VoiceServer voiceServer=new VoiceServer();

    private void btnVoiceServerMaxActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnVoiceServerMaxActionPerformed
     
        try {
            video_server.startVideoServer();
            voiceServer.startVoiceCall();
        } catch (IOException | ClassNotFoundException ex) {
            Logger.getLogger(chat_server.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }//GEN-LAST:event_btnVoiceServerMaxActionPerformed

    private void btnEndCallActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEndCallActionPerformed
        // TODO add your handling code here:
        voiceServer.endCall();
        videoServer.endVideoCall();

    }//GEN-LAST:event_btnEndCallActionPerformed

    private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_jButton1ActionPerformed

    JFileChooser fileChooser = new JFileChooser();
    int result = fileChooser.showOpenDialog(this);
    if (result == JFileChooser.APPROVE_OPTION) {
        File fileToSend = fileChooser.getSelectedFile();
        try {
            dout.writeUTF("sending_file"); // إشعار الطرف الآخر
            dout.writeUTF(fileToSend.getName());
            dout.writeLong(fileToSend.length());

            FileInputStream fis = new FileInputStream(fileToSend);
            byte[] buffer = new byte[4096];
            int count;
            while ((count = fis.read(buffer)) > 0) {
                dout.write(buffer, 0, count);
            }
            fis.close();

            // استخدم appendMessage بدل append مباشرة
            appendMessage("Me: [File Sent] " + fileToSend.getName(), true);

        } catch (Exception e) {
            appendMessage("Me: [Error Sending File]", true);
        }   }
    }//GEN-LAST:event_jButton1ActionPerformed

    public static void main(String args[]) throws IOException {
      
        java.awt.EventQueue.invokeLater(new Runnable() {
            @Override
            public void run() {
                new chat_server().setVisible(true);
            }
        });
        
        String msgin="";

            sss=new ServerSocket(1201); //server starts at 1201 port number
            ss= sss.accept(); // server will accept the connection
            din= new DataInputStream(ss.getInputStream());
            dout=new DataOutputStream(ss.getOutputStream());
            
         while (!msgin.equals("exit")) {
    msgin = din.readUTF();

    if (msgin.equals("sending_file")) {
        String fileName = din.readUTF();
        long fileSize = din.readLong();

        File file = new File("received_" + fileName); // حفظ الملف في المجلد الحالي
        FileOutputStream fos = new FileOutputStream(file);

        byte[] buffer = new byte[4096];
        int count;
        long totalRead = 0;

        while (totalRead < fileSize && (count = din.read(buffer, 0, (int)Math.min(buffer.length, fileSize - totalRead))) > 0) {
            fos.write(buffer, 0, count);
            totalRead += count;
        }
        
        fos.close();
                 ((chat_server)javax.swing.JFrame.getFrames()[0]).appendMessage("Client: " +file.getName(), false);

    } else {
        ((chat_server)javax.swing.JFrame.getFrames()[0]).appendMessage("Client: " + msgin, false);
    }
}
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btnEndCall;
    private javax.swing.JButton btnVoiceServer;
    private javax.swing.JButton btnVoiceServerMax;
    private javax.swing.JButton jButton1;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JButton msg_send;
    private javax.swing.JTextField msg_text;
    private javax.swing.JTextPane txtPaneChat;
    private javax.swing.JButton video_chat;
    // End of variables declaration//GEN-END:variables
}


